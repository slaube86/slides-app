import { useRef, useState } from 'react';
import { useDeck } from '../store/deckStore';
import { storeImageFile } from '../db/assetCache';
import { exportDeckJson, importDeckJson } from '../export/json';

interface Props {
  onPresent: () => void;
}

export function Toolbar({ onPresent }: Props) {
  const deck = useDeck((s) => s.deck)!;
  const setTitle = useDeck((s) => s.setTitle);
  const addText = useDeck((s) => s.addText);
  const addShape = useDeck((s) => s.addShape);
  const addImage = useDeck((s) => s.addImage);
  const setDeck = useDeck((s) => s.setDeck);
  const undo = useDeck((s) => s.undo);
  const redo = useDeck((s) => s.redo);
  const canUndo = useDeck((s) => s.past.length > 0);
  const canRedo = useDeck((s) => s.future.length > 0);
  const dirty = useDeck((s) => s.dirty);

  const fileRef = useRef<HTMLInputElement>(null);
  const importRef = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);

  async function onPickImage(file: File) {
    const asset = await storeImageFile(file);
    const dims = await imageDimensions(file);
    addImage(asset.id, dims.width, dims.height);
  }

  async function onImportFile(file: File) {
    try {
      const imported = await importDeckJson(file);
      setDeck(imported);
    } catch (err) {
      alert('Import fehlgeschlagen: ' + (err as Error).message);
    }
  }

  return (
    <header className="toolbar">
      <div className="toolbar-group">
        <strong className="brand">▥ Slides</strong>
        <input
          className="title-input"
          value={deck.title}
          onChange={(e) => setTitle(e.target.value)}
          aria-label="Titel"
        />
        <span className={`save-dot${dirty ? ' dirty' : ''}`} title={dirty ? 'Speichern…' : 'Gespeichert'} />
      </div>

      <div className="toolbar-group">
        <button className="btn" onClick={() => addText('title')}>Titel</button>
        <button className="btn" onClick={() => addText('body')}>Text</button>
        <button className="btn" onClick={() => addShape('rect')}>▭</button>
        <button className="btn" onClick={() => addShape('ellipse')}>◯</button>
        <button className="btn" onClick={() => addShape('line')}>╱</button>
        <button className="btn" onClick={() => fileRef.current?.click()}>🖼 Bild</button>
      </div>

      <div className="toolbar-group">
        <button className="btn" onClick={undo} disabled={!canUndo} title="Rückgängig (⌘Z)">↶</button>
        <button className="btn" onClick={redo} disabled={!canRedo} title="Wiederholen (⌘⇧Z)">↷</button>
      </div>

      <div className="toolbar-group right">
        <button className="btn" onClick={() => importRef.current?.click()}>Import</button>
        <button className="btn" onClick={() => exportDeckJson(deck)}>JSON</button>
        <button
          className="btn"
          disabled={busy}
          onClick={async () => {
            setBusy(true);
            try {
              const { exportDeckPdf } = await import('../export/pdf');
              await exportDeckPdf(deck);
            } finally {
              setBusy(false);
            }
          }}
        >
          {busy ? 'PDF…' : 'PDF'}
        </button>
        <button className="btn primary" onClick={onPresent}>▶ Präsentieren</button>
      </div>

      <input
        ref={fileRef}
        type="file"
        accept="image/*"
        hidden
        onChange={(e) => {
          const f = e.target.files?.[0];
          if (f) onPickImage(f);
          e.target.value = '';
        }}
      />
      <input
        ref={importRef}
        type="file"
        accept="application/json,.json"
        hidden
        onChange={(e) => {
          const f = e.target.files?.[0];
          if (f) onImportFile(f);
          e.target.value = '';
        }}
      />
    </header>
  );
}

function imageDimensions(file: File): Promise<{ width: number; height: number }> {
  return new Promise((resolve) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      resolve({ width: img.naturalWidth, height: img.naturalHeight });
      URL.revokeObjectURL(url);
    };
    img.onerror = () => {
      resolve({ width: 400, height: 300 });
      URL.revokeObjectURL(url);
    };
    img.src = url;
  });
}
